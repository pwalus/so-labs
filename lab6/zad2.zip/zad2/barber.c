#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/file.h>
#include <sys/msg.h>
#include <stdlib.h>
#include <memory.h>
#include <sys/time.h>
#include <signal.h>
#include <zconf.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include "global.h"

struct message receivedMessage;

int initQueue();

int initBarberSemaphore();

void destroyQueue(int serverId);

void destroySemaphore(int barber, int invitation, int seat, int cut);

void sendInvitation(int invitation);

void waitForSit(int seat);

void sendEnd(int cut);

void sleepBarber(int barber);

void printTime();

int initInvitationSemaphore(int numberOfSeats);

int initSeatSemaphore(int numberOfSeats);

int initCutSemaphore(int numberOfSeats);

int *initIsSleeping();

int *initNumberOfSeats(int number);

int *initTakenSeats();

void stopBarber(int signal);

int main(int argc, char *argv[]) {
    if (argc != 2) {
        exit(-1);
    }

    int numberOfSeatsCommand = atoi(argv[1]);

    int serverId = initQueue();
    int barber = initBarberSemaphore();
    int invitation = initInvitationSemaphore(NUMBER_OF_SEATS);
    int seat = initSeatSemaphore(NUMBER_OF_SEATS);
    int cut = initCutSemaphore(NUMBER_OF_SEATS);

    int *isSleeping = initIsSleeping();
    initNumberOfSeats(numberOfSeatsCommand);
    int *takenSeats = initTakenSeats();


    struct sigaction signalData;
    signalData.sa_flags = 0;
    sigemptyset(&signalData.sa_mask);
    signalData.sa_handler = stopBarber;
    sigaction(SIGINT, &signalData, 0);

    while (1) {
        if (*takenSeats == 0) {
            *isSleeping = BARBER_SLEEP;

            sleepBarber(barber);

            *isSleeping = BARBER_NOT_SLEEP;
            printf("BARBER: woke up\n");
        }

        printf("BARBER: get clients from queue\n");
        if (msgrcv(serverId, &receivedMessage, sizeof(struct message), 0, 0) == -1) {
            perror("BARBER: error with msrcv");
            exit(1);
        }

        printf("BARBER: ID SEMAPHORE%d \n", receivedMessage.clientSeatId);

        sendInvitation(invitation);
        waitForSit(seat);

        printf("BARBER: CLIENT is cut %d\n", receivedMessage.clientPid);
        sleep(4);

        sendEnd(cut);
    }
}

void printTime() {
    struct timespec time;
    clock_gettime(CLOCK_MONOTONIC, &time);
    long duration = time.tv_sec + time.tv_nsec;
    printf("%li ----- ", duration);
}

void sendInvitation(int invitation) {
    struct sembuf sops;

    sops.sem_num = (unsigned short) receivedMessage.clientSeatId;
    sops.sem_op = 1;
    sops.sem_flg = 0;

    printTime();
    printf("BARBER: invites client to chair %d\n", receivedMessage.clientPid);
    if (semop(invitation, &sops, 1) == -1) {
        perror("BARBER: cannot change semaphore value");
        exit(1);
    }

}

void waitForSit(int seat) {
    struct sembuf sops;

    sops.sem_num = (unsigned short) receivedMessage.clientSeatId;
    sops.sem_op = -1;
    sops.sem_flg = 0;

    if (semop(seat, &sops, 1) == -1) {
        perror("BARBER: cannot change semaphore value");
        exit(1);
    }

    printTime();
    printf("BARBER: client sit down %d\n", receivedMessage.clientPid);
}

void sendEnd(int cut) {
    struct sembuf sops;
    sops.sem_num = (unsigned short) receivedMessage.clientSeatId;
    sops.sem_op = 1;
    sops.sem_flg = 0;

    printTime();
    printf("BARBER: ended cutting client %d\n", receivedMessage.clientPid);
    if (semop(cut, &sops, 1) == -1) {
        perror("BARBER: cannot change semaphore value");
        exit(1);
    }
}

void sleepBarber(int barber) {
    struct sembuf sops;
    printf("BARBER: going to sleep\n");

    sops.sem_num = SEMAPHORE_ID;
    sops.sem_op = -1;
    sops.sem_flg = 0;

    if (semop(barber, &sops, 1) == -1) {
        perror("BARBER: cannot change semaphore value");
        exit(1);
    }
}

int initQueue() {
    key_t key;
    int serverId;
    int handle = open(QUEUE_PATH_NAME, O_RDONLY);
    if (handle == -1) {
        creat(QUEUE_PATH_NAME, PERMISSIONS);
    }
    close(handle);

    if ((key = ftok(QUEUE_PATH_NAME, QUEUE_PROJECT_ID)) == -1) {
        perror("BARBER: Cannot create key");
        exit(1);
    }

    if ((serverId = msgget(key, IPC_CREAT | PERMISSIONS)) == -1) {
        perror("BARBER: Cannot create queue");
        exit(1);
    }

    return serverId;
}

int initBarberSemaphore() {
    key_t key;
    int barber;
    int handle = open(SEMAPHORE_PATH_NAME, O_RDONLY);
    if (handle == -1) {
        creat(SEMAPHORE_PATH_NAME, PERMISSIONS);
    }
    close(handle);

    if ((key = ftok(SEMAPHORE_PATH_NAME, SEMAPHORE_PROJECT_ID)) == -1) {
        perror("BARBER: Cannot create key");
        exit(1);
    }

    if ((barber = semget(key, 1, IPC_CREAT | PERMISSIONS)) == -1) {
        perror("BARBER: Cannot create semaphore");
        exit(1);
    }


    union semun arg;
    arg.val = 0;
    semctl(barber, SEMAPHORE_ID, SETVAL, arg.val);

    return barber;
}

int initInvitationSemaphore(int numberOfSeats) {
    key_t key;
    int invitation;
    int handle = open(SEMAPHORE_INVITATION_NAME, O_RDONLY);
    if (handle == -1) {
        creat(SEMAPHORE_INVITATION_NAME, PERMISSIONS);
    }
    close(handle);

    if ((key = ftok(SEMAPHORE_INVITATION_NAME, SEMAPHORE_INVITATION_PROJECT_ID)) == -1) {
        perror("BARBER: Cannot create key");
        exit(1);
    }

    if ((invitation = semget(key, numberOfSeats + 1, IPC_CREAT | PERMISSIONS)) == -1) {
        perror("BARBER: Cannot create semaphore");
        exit(1);
    }

    union semun arg;
    arg.val = 0;
    for (int i = 0; i < numberOfSeats; ++i) {
        semctl(invitation, numberOfSeats, SETVAL, arg.val);
    }

    return invitation;
}

int initSeatSemaphore(int numberOfSeats) {
    key_t key;
    int seat;
    int handle = open(SEMAPHORE_SEAT_NAME, O_RDONLY);
    if (handle == -1) {
        creat(SEMAPHORE_SEAT_NAME, PERMISSIONS);
    }
    close(handle);

    if ((key = ftok(SEMAPHORE_SEAT_NAME, SEMAPHORE_SEAT_PROJECT_ID)) == -1) {
        perror("BARBER: Cannot create key");
        exit(1);
    }

    if ((seat = semget(key, numberOfSeats + 1, IPC_CREAT | PERMISSIONS)) == -1) {
        perror("BARBER: Cannot create semaphore");
        exit(1);
    }


    union semun arg;
    arg.val = 0;
    for (int i = 0; i < numberOfSeats; ++i) {
        semctl(seat, numberOfSeats, SETVAL, arg.val);
    }

    return seat;
}

int initCutSemaphore(int numberOfSeats) {
    key_t key;
    int cut;
    int handle = open(SEMAPHORE_CUT_NAME, O_RDONLY);
    if (handle == -1) {
        creat(SEMAPHORE_CUT_NAME, PERMISSIONS);
    }
    close(handle);

    if ((key = ftok(SEMAPHORE_CUT_NAME, SEMAPHORE_CUT_PROJECT_ID)) == -1) {
        perror("BARBER: Cannot create key");
        exit(1);
    }

    if ((cut = semget(key, numberOfSeats + 1, IPC_CREAT | PERMISSIONS)) == -1) {
        perror("BARBER: Cannot create semaphore");
        exit(1);
    }


    union semun arg;
    arg.val = 0;
    for (int i = 0; i < numberOfSeats; ++i) {
        semctl(cut, numberOfSeats, SETVAL, arg.val);
    }

    return cut;
}

void destroyQueue(int serverId) {
    if (msgctl(serverId, IPC_RMID, NULL) == -1) {
        perror("BARBER: Cannot delete queue");
        exit(1);
    }
}


void destroySemaphore(int barber, int invitation, int seat, int cut) {
    if (semctl(barber, SEMAPHORE_ID, IPC_RMID, NULL) == -1) {
        perror("BARBER: Cannot delete semaphore");
        exit(1);
    }

    if (semctl(invitation, SEMAPHORE_ID, IPC_RMID, NULL) == -1) {
        perror("BARBER: Cannot delete semaphore");
        exit(1);
    }

    if (semctl(seat, SEMAPHORE_ID, IPC_RMID, NULL) == -1) {
        perror("BARBER: Cannot delete semaphore");
        exit(1);
    }

    if (semctl(cut, SEMAPHORE_ID, IPC_RMID, NULL) == -1) {
        perror("BARBER: Cannot delete semaphore");
        exit(1);
    }
}

int *initIsSleeping() {
    key_t sleepingKey;
    int isSleepingId;
    int *isSleeping;

    int handle = open("is_sleeping", O_RDONLY);
    if (handle == -1) {
        creat("is_sleeping", PERMISSIONS);
    }
    close(handle);

    if ((sleepingKey = ftok("is_sleeping", 'q')) == -1) {
        perror("BARBER: Cannot create sleepingKey");
        exit(1);
    }

    if ((isSleepingId = shmget(sleepingKey, (sizeof(int)), IPC_CREAT | PERMISSIONS)) == -1) {
        perror("BARBER: Cannot create shared memory");
        exit(1);
    }

    if ((isSleeping = (int *) shmat(isSleepingId, (void *) 0, 0)) == (int *) -1) {
        perror("BARBER: cannot allocate shared memory");
        exit(1);
    }

    *isSleeping = 1;

    return isSleeping;
}

int *initNumberOfSeats(int number) {
    key_t key;
    int numberOfSeatsId;
    int *numberOfSeats;

    int handle = open("number_of_seats", O_RDONLY);
    if (handle == -1) {
        creat("number_of_seats", PERMISSIONS);
    }
    close(handle);

    if ((key = ftok("number_of_seats", 'w')) == -1) {
        perror("BARBER: Cannot create key");
        exit(1);
    }

    if ((numberOfSeatsId = shmget(key, (sizeof(int)), IPC_CREAT | PERMISSIONS)) == -1) {
        perror("BARBER: Cannot create shared memory");
        exit(1);
    }

    if ((numberOfSeats = (int *) shmat(numberOfSeatsId, (void *) 0, 0)) == (int *) -1) {
        perror("BARBER: cannot allocate shared memory");
        exit(1);
    }

    *numberOfSeats = number;

    return numberOfSeats;
}

int *initTakenSeats() {
    key_t key;
    int takenSeatsId;
    int *takenSeats;

    int handle = open("taken_seats", O_RDONLY);
    if (handle == -1) {
        creat("taken_seats", PERMISSIONS);
    }
    close(handle);

    if ((key = ftok("taken_seats", 'e')) == -1) {
        perror("BARBER: Cannot create key");
        exit(1);
    }

    if ((takenSeatsId = shmget(key, (sizeof(int)), IPC_CREAT | PERMISSIONS)) == -1) {
        perror("BARBER: Cannot create shared memory");
        exit(1);
    }

    if ((takenSeats = (int *) shmat(takenSeatsId, (void *) 0, 0)) == (int *) -1) {
        perror("BARBER: cannot allocate shared memory");
        exit(1);
    }

    *takenSeats = 0;

    return takenSeats;
}

void stopBarber(int signal) {
    printf("-------------------------------\n");
    printf("SERVER: ENDING PROCESS...\n");
    printf("-------------------------------\n");

    execl("./clean", "./clean", 0);

    kill(receivedMessage.clientPid, SIGKILL);
    exit(1);
}
