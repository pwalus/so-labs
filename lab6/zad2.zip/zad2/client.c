#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/file.h>
#include <sys/msg.h>
#include <stdlib.h>
#include <memory.h>
#include <sys/time.h>
#include <signal.h>
#include <zconf.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include "global.h"

struct message sendMessage;

int initQueue();

int initBarberSemaphore();

int initSeatSemaphore();

int initInvitationSemaphore();

int initCutSemaphore();

void waitForInvitation(int invitation, int seatId);

void sittingOnChair(int seat, int seatId);

void waitForEndCutting(int cut, int seatId);

void printTime();

int *initIsSleeping();

int *initNumberOfSeats();

int *initTakenSeats();

int main(int argc, char *argv[]) {
    if (argc != 3) {
        exit(-1);
    }

    int serverId = initQueue();
    int barber = initBarberSemaphore();
    int invitation = initInvitationSemaphore();
    int seat = initSeatSemaphore();
    int cut = initCutSemaphore();

    int *isSleeping = initIsSleeping();
    int *numberOfSeats = initNumberOfSeats();
    int *takenSeats = initTakenSeats();

    struct sembuf sops;

    int numberOfClients = atoi(argv[1]);
    int numberOfCuts = atoi(argv[1]);


    for (int j = 0; j < numberOfClients; ++j) {
        pid_t clientPid = fork();
        if (clientPid == 0) {
            for (int i = 0; i < numberOfCuts; ++i) {
                int seatId = 0;

                if (*isSleeping == BARBER_SLEEP && (*takenSeats == 0)) {
                    sendMessage.clientPid = getpid();
                    sendMessage.type = 1;

                    if (msgsnd(serverId, &sendMessage, sizeof(struct message), 0) == -1) {
                        perror("CLIENT: Error with msgsnd");
                        exit(-1);
                    }

                    sops.sem_num = SEMAPHORE_ID;
                    sops.sem_op = 1;
                    sops.sem_flg = 0;
                    if (semop(barber, &sops, 1) == -1) {
                        perror("CLIENT: cannot change semaphore value");
                        exit(1);
                    }

                    printf("CLIENT %d: Waking up barber\n", getpid());
                } else if (*takenSeats < *numberOfSeats) {
                    (*takenSeats)++;
                    seatId = (*takenSeats);

                    printf("CLIENT %d: Waiting in waiting room...\n", getpid());
                    printf("CLIENT %d: Taken seats: %d\n", getpid(), (*takenSeats));

                    sendMessage.clientPid = getpid();
                    sendMessage.clientSeatId = seatId;
                    sendMessage.type = 1;

                    if (msgsnd(serverId, &sendMessage, sizeof(struct message), 0) == -1) {
                        perror("CLIENT: Error with msgsnd");
                        exit(-1);
                    }
                } else {
                    printf("CLIENT %d: No more seats...\n", getpid());
                    sleep(5);
                    i--;

                    continue;
                }

                printf("CLIENT: %d ID SEMAPHORE %d\n", getpid(), seatId);

                waitForInvitation(invitation, seatId);
                sittingOnChair(seat, seatId);
                waitForEndCutting(cut, seatId);

                printTime();
                printf("CLIENT %d: Leaving barber\n", getpid());


                (*takenSeats)--;
                if ((*takenSeats) < 0) {
                    (*takenSeats) = 0;
                }
            }

            printf("CLIENT %d: End of all cuts\n", getpid());
        } else {
            if (j == (numberOfClients - 1)) {
                sleep(1000);
            }
        }
    }

    shmdt(isSleeping);
    shmdt(takenSeats);
    shmdt(numberOfSeats);

    return 0;
}

int *initIsSleeping() {
    key_t key;
    int isSleepingId;
    int *isSleeping;

    if ((key = ftok("is_sleeping", 'q')) == -1) {
        perror("CLIENT: Cannot create key");
        exit(1);
    }

    if ((isSleepingId = shmget(key, (sizeof(int)), IPC_CREAT | PERMISSIONS)) == -1) {
        perror("CLIENT: Cannot create shared memory");
        exit(1);
    }

    if ((isSleeping = (int *) shmat(isSleepingId, (void *) 0, 0)) == (int *) -1) {
        perror("CLIENT: cannot allocate shared memory");
        exit(1);
    }

    return isSleeping;
}

int *initNumberOfSeats() {
    key_t key;
    int numberOfSeatsId;
    int *numberOfSeats;

    if ((key = ftok("number_of_seats", 'w')) == -1) {
        perror("CLIENT: Cannot create key");
        exit(1);
    }

    if ((numberOfSeatsId = shmget(key, (sizeof(int)), IPC_CREAT | PERMISSIONS)) == -1) {
        perror("CLIENT: Cannot create shared memory");
        exit(1);
    }

    if ((numberOfSeats = (int *) shmat(numberOfSeatsId, (void *) 0, 0)) == (int *) -1) {
        perror("CLIENT: cannot allocate shared memory");
        exit(1);
    }

    return numberOfSeats;
}

int *initTakenSeats() {
    key_t key;
    int takenSeatsId;
    int *takenSeats;

    if ((key = ftok("taken_seats", 'e')) == -1) {
        perror("CLIENT: Cannot create key");
        exit(1);
    }

    if ((takenSeatsId = shmget(key, (sizeof(int)), IPC_CREAT | PERMISSIONS)) == -1) {
        perror("CLIENT: Cannot create shared memory");
        exit(1);
    }

    if ((takenSeats = (int *) shmat(takenSeatsId, (void *) 0, 0)) == (int *) -1) {
        perror("CLIENT: cannot allocate shared memory");
        exit(1);
    }

    return takenSeats;
}

void printTime() {
    struct timespec time;
    clock_gettime(CLOCK_MONOTONIC, &time);
    long duration = time.tv_sec + time.tv_nsec;
    printf("%li ----- ", duration);
}

void waitForInvitation(int invitation, int seatId) {
    struct sembuf sops;
    sops.sem_num = (unsigned short) seatId;
    sops.sem_op = -1;
    sops.sem_flg = 0;


    printTime();
    printf("CLIENT %d: Waiting for invitation\n", getpid());
    if (semop(invitation, &sops, 1) == -1) {
        perror("CLIENT: cannot change semaphore value");
        exit(1);
    }
}

void sittingOnChair(int seat, int seatId) {
    struct sembuf sops;
    sops.sem_num = (unsigned short) seatId;
    sops.sem_op = 1;
    sops.sem_flg = 0;

    printTime();
    printf("CLIENT %d: Sitting on chair\n", getpid());
    sleep(2);
    if (semop(seat, &sops, 1) == -1) {
        perror("CLIENT: cannot change semaphore value");
        exit(1);
    }
}

void waitForEndCutting(int cut, int seatId) {
    struct sembuf sops;

    sops.sem_num = (unsigned short) seatId;
    sops.sem_op = -1;
    sops.sem_flg = 0;

    printTime();
    printf("CLIENT %d: Sits on chair and is being cut\n", getpid());
    if (semop(cut, &sops, 1) == -1) {
        perror("CLIENT: cannot change semaphore value");
        exit(1);
    }
}

int initQueue() {
    key_t key;
    int serverId;

    if ((key = ftok(QUEUE_PATH_NAME, QUEUE_PROJECT_ID)) == -1) {
        perror("CLIENT: Cannot create key");
        exit(1);
    }

    if ((serverId = msgget(key, IPC_CREAT | PERMISSIONS)) == -1) {
        perror("CLIENT: Cannot create queue");
        exit(1);
    }

    return serverId;

}

int initBarberSemaphore() {
    key_t key;
    int barber;

    if ((key = ftok(SEMAPHORE_PATH_NAME, SEMAPHORE_PROJECT_ID)) == -1) {
        perror("CLIENT: Cannot create key");
        exit(1);
    }

    if ((barber = semget(key, 0, 0)) == -1) {
        perror("CLIENT: Cannot create semaphore");
        exit(1);
    }

    return barber;
}

int initInvitationSemaphore() {
    key_t key;
    int invitation;

    if ((key = ftok(SEMAPHORE_INVITATION_NAME, SEMAPHORE_INVITATION_PROJECT_ID)) == -1) {
        perror("CLIENT: Cannot create key");
        exit(1);
    }

    if ((invitation = semget(key, 0, 0)) == -1) {
        perror("CLIENT: Cannot create semaphore");
        exit(1);
    }

    return invitation;
}

int initSeatSemaphore() {
    key_t key;
    int seat;

    if ((key = ftok(SEMAPHORE_SEAT_NAME, SEMAPHORE_SEAT_PROJECT_ID)) == -1) {
        perror("CLIENT: Cannot create key");
        exit(1);
    }

    if ((seat = semget(key, 0, 0)) == -1) {
        perror("CLIENT: Cannot create semaphore");
        exit(1);
    }

    return seat;
}

int initCutSemaphore() {
    key_t key;
    int cut;

    if ((key = ftok(SEMAPHORE_CUT_NAME, SEMAPHORE_CUT_PROJECT_ID)) == -1) {
        perror("CLIENT: Cannot create key");
        exit(1);
    }

    if ((cut = semget(key, 0, 0)) == -1) {
        perror("CLIENT: Cannot create semaphore");
        exit(1);
    }

    return cut;
}
